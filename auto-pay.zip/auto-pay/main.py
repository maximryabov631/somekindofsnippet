#!/usr/bin/env python3
"""
Auto-Pay for CR.BOT P2C: new order → Elplat SBP (bank100000000086) → tap pay → send-bot complete.

Commands:
  python main.py              # or: python main.py run
  python main.py sbp <url> [device]
"""

import argparse
import asyncio
import logging
import signal
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

from api.send_bot import SendBotClient
from config import ConfigError, load_config
from monitor import PaymentMonitor

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
logger = logging.getLogger("auto-pay")


class Application:
    """Main application: monitors accounts, Elplat pay, optional send-bot confirm."""

    def __init__(self, config_path: str):
        self.config_path = config_path
        self.monitors: list[PaymentMonitor] = []
        self.send_bot: SendBotClient | None = None
        self._shutdown_event = asyncio.Event()

    async def run(self) -> int:
        try:
            config = load_config(self.config_path)
        except ConfigError as e:
            logger.error(f"Config error: {e}")
            return 1

        logger.info(f"Loaded {len(config.accounts)} account(s)")
        logger.info(f"Poll interval: {config.monitor.poll_interval_seconds}s")

        if config.send_bot.enabled:
            ch = config.send_bot.cookie_header()
            cr = config.send_bot.effective_cr_account_id()
            if ch and cr:
                self.send_bot = SendBotClient(
                    base_url=config.send_bot.base_url,
                    cookie_header=ch,
                    account_key_name=config.send_bot.account_key_name,
                    cr_account_id=cr,
                    cr_domain=config.send_bot.cr_domain,
                )
                logger.info("send-bot completion enabled (POST …/payments/{id}/complete)")
            else:
                logger.warning(
                    "send_bot.enabled but session_cookie / cr_account_id missing "
                    "(set in config.toml or SEND_BOT_SESSION_COOKIE / SEND_BOT_CR_ACCOUNT_ID)"
                )

        for account in config.accounts:
            monitor = PaymentMonitor(
                account=account,
                poll_interval=config.monitor.poll_interval_seconds,
                elplat_wait_before_pay_seconds=config.elplat.wait_before_pay_seconds,
                elplat_fallback_tap=config.elplat.fallback_tap,
                adb_serial=config.adb.serial,
                adb_binary=config.adb.binary,
                send_bot=self.send_bot,
            )
            self.monitors.append(monitor)
            logger.info(f"Created monitor for account: {account.name}")

        loop = asyncio.get_running_loop()
        for sig in (signal.SIGINT, signal.SIGTERM):
            loop.add_signal_handler(sig, self._handle_shutdown)

        try:
            tasks = [
                asyncio.create_task(monitor.start(), name=f"monitor-{monitor.account.name}")
                for monitor in self.monitors
            ]
            await self._shutdown_event.wait()
            for monitor in self.monitors:
                monitor.stop()
            await asyncio.gather(*tasks, return_exceptions=True)
        except Exception as e:
            logger.exception(f"Application error: {e}")
            return 1
        finally:
            if self.send_bot:
                await self.send_bot.close()

        logger.info("Application stopped")
        return 0

    def _handle_shutdown(self) -> None:
        logger.info("Shutdown signal received")
        self._shutdown_event.set()


async def cmd_sbp(args: argparse.Namespace) -> int:
    """Open Elplat for one QR link (delegates to open_sbp logic)."""
    from open_sbp import run_sbp_once

    return await run_sbp_once(
        args.url_or_token,
        config_path=args.config,
        device=args.device or "",
    )


def main() -> int:
    parser = argparse.ArgumentParser(
        description="CR.BOT P2C auto-pay: Elplat SBP + optional send-bot complete",
    )
    parser.add_argument(
        "-c",
        "--config",
        default="config.toml",
        help="Path to config.toml",
    )
    sub = parser.add_subparsers(dest="command", required=False)

    sub.add_parser("run", help="Start monitors (default if no subcommand)")

    sp = sub.add_parser("sbp", help="Open one qr.nspk.ru payment in Elplat and tap pay")
    sp.add_argument("url_or_token", help="https URL, path token, or bank100000000086://…")
    sp.add_argument("device", nargs="?", default="", help="ADB serial, e.g. 127.0.0.1:5555")

    argv = sys.argv[1:]
    if argv and argv[0] not in ("-h", "--help", "run", "sbp", "-c", "--config"):
        if not argv[0].startswith("-"):
            sys.argv = [sys.argv[0], "sbp", *argv]

    args = parser.parse_args()

    if args.command == "sbp":
        return asyncio.run(cmd_sbp(args))

    return asyncio.run(_run_monitor(args))


async def _run_monitor(args: argparse.Namespace) -> int:
    app = Application(args.config)
    return await app.run()


if __name__ == "__main__":
    sys.exit(main())
