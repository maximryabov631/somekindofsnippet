#!/usr/bin/env python3
"""
open_sbp.py — open qr.nspk.ru in Elplat and tap the pay button (same flow as ElplatHandler).

Usage:
    python open_sbp.py <qr_url_or_token>
    python open_sbp.py <qr_url_or_token> --device 127.0.0.1:5575
    python main.py sbp <qr_url_or_token> [device]
"""

from __future__ import annotations

import argparse
import asyncio
import logging
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

from api.types import PaymentDetails
from config import ConfigError, load_config
from handlers.elplat import ElplatHandler

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)-8s | %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
logger = logging.getLogger("open_sbp")


def normalize_payment_url(raw: str) -> str:
    """Turn token or partial input into an https qr.nspk.ru URL for PaymentDetails."""
    raw = raw.strip()
    if raw.startswith("bank") and "://" in raw:
        return raw
    if not raw.startswith(("http://", "https://")):
        return f"https://qr.nspk.ru/{raw}"
    return raw


async def run_sbp_once(
    url_or_token: str,
    *,
    config_path: str = "config.toml",
    device: str = "",
    wait: float | None = None,
) -> int:
    """Run one Elplat open + tap. Used by open_sbp CLI and ``main.py sbp``."""
    serial = (device or "").strip()
    w = wait
    fallback: tuple[int, int] | None = None
    adb_binary = "adb"

    try:
        cfg = load_config(config_path)
        if not serial:
            serial = cfg.adb.serial
        if w is None:
            w = cfg.elplat.wait_before_pay_seconds
        fallback = cfg.elplat.fallback_tap
        adb_binary = cfg.adb.binary
    except ConfigError as e:
        logger.warning("Config not loaded (%s); using CLI defaults only", e)

    if w is None:
        w = 4.0

    raw = url_or_token.strip()
    url = raw if raw.startswith("bank") and "://" in raw else normalize_payment_url(raw)

    handler = ElplatHandler(
        adb_serial=serial,
        adb_binary=adb_binary,
        wait_before_pay_seconds=w,
        fallback_tap=fallback,
    )

    payment = PaymentDetails(
        id=0,
        url=url,
        brand_name="Elplat",
        out_amount="",
        out_asset="RUB",
    )

    if not await handler.can_handle(payment):
        logger.error("URL is not a supported qr.nspk.ru payment link for Elplat.")
        return 1

    logger.info("ADB binary: %s", adb_binary)
    logger.info("Device serial: %s", serial or "(default adb device)")
    logger.info("Payment URL: %s", url)

    ok = await handler.auto_pay(payment)
    return 0 if ok else 1


async def main_async(args: argparse.Namespace) -> int:
    serial = args.device or ""
    if getattr(args, "device_legacy", None) and not serial:
        serial = args.device_legacy
    return await run_sbp_once(
        args.url_or_token,
        config_path=args.config,
        device=serial,
        wait=args.wait,
    )


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Open SBP qr.nspk.ru in Elplat and tap pay (ElplatHandler CLI).",
    )
    parser.add_argument("url_or_token", help="https://qr.nspk.ru/…, path token, or bank://…")
    parser.add_argument(
        "device_legacy",
        nargs="?",
        default=None,
        help="Optional device serial (same as --device)",
    )
    parser.add_argument("-c", "--config", default="config.toml", help="TOML for [adb] / [elplat]")
    parser.add_argument("-s", "--device", default="", help="ADB serial (e.g. 127.0.0.1:5555)")
    parser.add_argument(
        "-w",
        "--wait",
        type=float,
        default=None,
        help="Seconds before pay button search (default from config or 4)",
    )
    args = parser.parse_args()
    if args.device_legacy and not args.device:
        args.device = args.device_legacy
    return asyncio.run(main_async(args))


if __name__ == "__main__":
    sys.exit(main())
