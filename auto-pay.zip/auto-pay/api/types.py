from dataclasses import dataclass
from datetime import datetime
from enum import Enum
from typing import Optional


class PaymentStatus(str, Enum):
    PROCESSING = "processing"
    COMPLETED = "completed"
    CANCELED = "canceled"
    DISPUTED = "disputed"
    REFUNDED = "refunded"


class Provider(str, Enum):
    NSPK = "nspk"
    PLATIQR = "platiqr"


@dataclass
class Payment:
    """Basic payment info from get_payments endpoint."""

    id: int
    asset: str
    fiat: str
    amount: float
    amount_fiat: float
    provider: str
    reward_percent: int
    status: PaymentStatus
    processing_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    is_unlocked: Optional[bool] = None


@dataclass
class PaymentAccount:
    """Bank account details for payment."""

    bank: Optional[str] = None
    number: Optional[str] = None
    holder: Optional[str] = None


@dataclass
class PaymentDetails:
    """Extended payment info from get_payment_by_id endpoint."""

    id: int
    payload: Optional[str] = None
    url: Optional[str] = None
    brand_name: Optional[str] = None
    in_asset: Optional[str] = None
    in_amount: Optional[str] = None
    out_asset: Optional[str] = None
    out_amount: Optional[str] = None
    exchange_rate: Optional[str] = None
    reward_amount: Optional[str] = None
    status: Optional[PaymentStatus] = None
    processing_at: Optional[str] = None
    completed_at: Optional[str] = None
    canceled_at: Optional[str] = None
    provider: Optional[str] = None
    account: Optional[PaymentAccount] = None

    @property
    def bank_name(self) -> Optional[str]:
        """Get bank name from account or brand_name."""
        if self.account and self.account.bank:
            return self.account.bank
        return self.brand_name
