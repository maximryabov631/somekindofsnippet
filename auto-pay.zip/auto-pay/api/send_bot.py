"""Client for send-bot.com QR payment completion (after Elplat pay)."""

from __future__ import annotations

import logging
from typing import Optional

import aiohttp

logger = logging.getLogger(__name__)


class SendBotError(Exception):
    """send-bot.com API error."""

    pass


class SendBotClient:
    """POST /api/qr/payments/{id}/complete with NextAuth session cookie."""

    def __init__(
        self,
        base_url: str,
        cookie_header: str,
        account_key_name: str,
        cr_account_id: str,
        cr_domain: str,
        timeout: int = 30,
    ):
        self._base = base_url.rstrip("/")
        self._cookie_header = cookie_header
        self._account_key_name = account_key_name
        self._cr_account_id = cr_account_id
        self._cr_domain = cr_domain
        self._timeout = aiohttp.ClientTimeout(total=timeout)
        self._session: Optional[aiohttp.ClientSession] = None

    async def _get_session(self) -> aiohttp.ClientSession:
        if self._session is None or self._session.closed:
            headers = {
                "Accept": "application/json",
                "Content-Type": "application/json",
                "Cookie": self._cookie_header,
            }
            self._session = aiohttp.ClientSession(timeout=self._timeout, headers=headers)
        return self._session

    async def close(self) -> None:
        if self._session and not self._session.closed:
            await self._session.close()

    async def complete_qr_payment(self, payment_id: int) -> tuple[bool, str]:
        """Tell send-bot that the QR payment was completed. payment_id = P2C order id."""
        url = f"{self._base}/api/qr/payments/{payment_id}/complete"
        body = {
            "accountKeyName": self._account_key_name,
            "crAccountId": self._cr_account_id,
            "crDomain": self._cr_domain,
        }
        session = await self._get_session()
        try:
            async with session.post(url, json=body) as resp:
                text = await resp.text()
                snippet = (text[:500] + "…") if len(text) > 500 else text
                if resp.status in (200, 201, 204):
                    logger.info("send-bot complete: HTTP %s for payment_id=%s", resp.status, payment_id)
                    return True, snippet
                logger.warning(
                    "send-bot complete failed: HTTP %s payment_id=%s body=%s",
                    resp.status,
                    payment_id,
                    snippet,
                )
                return False, f"HTTP {resp.status}: {snippet}"
        except aiohttp.ClientError as e:
            logger.exception("send-bot complete request error: %s", e)
            raise SendBotError(str(e)) from e
