import logging
import ssl
from datetime import datetime
from typing import Optional

import aiohttp

from .types import Payment, PaymentAccount, PaymentDetails, PaymentStatus

logger = logging.getLogger(__name__)

BASE_URL = "https://app.cr.bot/internal/v1/p2c"


class P2CClientError(Exception):
    """Base exception for P2C client errors."""

    pass


class P2CClient:
    """Async client for CR.BOT P2C API."""

    def __init__(self, access_token: str, timeout: int = 15):
        self.access_token = access_token
        self.timeout = aiohttp.ClientTimeout(total=timeout)
        self._session: Optional[aiohttp.ClientSession] = None

        # Disable SSL verification (matches Rust SDK behavior)
        self._ssl_context = ssl.create_default_context()
        self._ssl_context.check_hostname = False
        self._ssl_context.verify_mode = ssl.CERT_NONE

    def _get_headers(self) -> dict[str, str]:
        return {
            "Cookie": f"access_token={self.access_token}",
            "Origin": "https://app.cr.bot",
            "Host": "app.cr.bot",
            "Referer": "https://app.cr.bot/p2c/orders",
            "Accept": "application/json, text/plain, */*",
        }

    async def _get_session(self) -> aiohttp.ClientSession:
        if self._session is None or self._session.closed:
            connector = aiohttp.TCPConnector(ssl=self._ssl_context)
            self._session = aiohttp.ClientSession(
                connector=connector,
                timeout=self.timeout,
                headers=self._get_headers(),
            )
        return self._session

    async def close(self) -> None:
        if self._session and not self._session.closed:
            await self._session.close()

    async def get_payments(self, size: int = 40) -> list[Payment]:
        """Fetch recent payments from the API."""
        session = await self._get_session()

        try:
            async with session.get(
                f"{BASE_URL}/payments",
                params={"size": min(size, 40)},
            ) as response:
                if response.status != 200:
                    text = await response.text()
                    logger.error(f"API error: {response.status} - {text}")
                    raise P2CClientError(f"API returned {response.status}: {text}")

                data = await response.json()
                payments = []

                for item in data.get("data", []):
                    try:
                        payment = self._parse_payment(item)
                        payments.append(payment)
                    except (KeyError, ValueError) as e:
                        logger.warning(f"Failed to parse payment: {e}")
                        continue

                return payments

        except aiohttp.ClientError as e:
            logger.error(f"Request failed: {e}")
            raise P2CClientError(f"Request failed: {e}") from e

    async def get_payment_by_id(self, payment_id: int) -> Optional[PaymentDetails]:
        """Fetch detailed payment info by ID."""
        session = await self._get_session()

        try:
            async with session.get(f"{BASE_URL}/payments/{payment_id}") as response:
                if response.status != 200:
                    text = await response.text()
                    logger.error(f"API error: {response.status} - {text}")
                    return None

                data = await response.json()
                payment_data = data.get("data")

                if not payment_data:
                    return None

                return self._parse_payment_details(payment_data)

        except aiohttp.ClientError as e:
            logger.error(f"Request failed: {e}")
            return None

    def _parse_payment(self, data: dict) -> Payment:
        """Parse payment data from API response."""
        status_str = data.get("status", "").lower()
        status = PaymentStatus(status_str) if status_str else PaymentStatus.PROCESSING

        processing_at = None
        if data.get("processing_at"):
            try:
                processing_at = datetime.fromisoformat(
                    data["processing_at"].replace("Z", "+00:00")
                )
            except ValueError:
                pass

        completed_at = None
        if data.get("completed_at"):
            try:
                completed_at = datetime.fromisoformat(
                    data["completed_at"].replace("Z", "+00:00")
                )
            except ValueError:
                pass

        return Payment(
            id=data["id"],
            asset=data.get("asset", "USDT"),
            fiat=data.get("fiat", "RUB"),
            amount=float(data.get("amount", 0)),
            amount_fiat=float(data.get("amount_fiat", 0)),
            provider=data.get("provider", ""),
            reward_percent=data.get("reward_percent", 0),
            status=status,
            processing_at=processing_at,
            completed_at=completed_at,
            is_unlocked=data.get("is_unlocked"),
        )

    def _parse_payment_details(self, data: dict) -> PaymentDetails:
        """Parse detailed payment data from API response."""
        status = None
        if data.get("status"):
            try:
                status = PaymentStatus(data["status"].lower())
            except ValueError:
                pass

        account = None
        if data.get("account"):
            acc_data = data["account"]
            account = PaymentAccount(
                bank=acc_data.get("bank"),
                number=acc_data.get("number"),
                holder=acc_data.get("holder"),
            )

        provider_data = data.get("provider")
        provider = None
        if isinstance(provider_data, dict):
            provider = provider_data.get("name")
        elif isinstance(provider_data, str):
            provider = provider_data

        return PaymentDetails(
            id=data.get("id", 0),
            payload=data.get("payload"),
            url=data.get("url"),
            brand_name=data.get("brand_name"),
            in_asset=data.get("in_asset"),
            in_amount=data.get("in_amount"),
            out_asset=data.get("out_asset"),
            out_amount=data.get("out_amount"),
            exchange_rate=data.get("exchange_rate"),
            reward_amount=data.get("reward_amount"),
            status=status,
            processing_at=data.get("processing_at"),
            completed_at=data.get("completed_at"),
            canceled_at=data.get("canceled_at"),
            provider=provider,
            account=account,
        )
