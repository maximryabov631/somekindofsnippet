import os
import sys
from dataclasses import dataclass, field
from pathlib import Path

if sys.version_info >= (3, 11):
    import tomllib
else:
    import tomli as tomllib


@dataclass
class AccountConfig:
    """Configuration for a single P2C account."""

    name: str
    access_token: str


@dataclass
class MonitorConfig:
    """Configuration for the payment monitor."""

    poll_interval_seconds: int = 3


@dataclass
class AdbConfig:
    """ADB: optional device serial and binary (BlueStacks HD-Adb.exe, etc.)."""

    serial: str = ""
    binary: str = "adb"


@dataclass
class ElplatConfig:
    """Elplat SBP (qr.nspk.ru). Scheme is bank100000000086 (NSPK member id for Elplat)."""

    wait_before_pay_seconds: float = 4.0
    fallback_tap_x: int | None = None
    fallback_tap_y: int | None = None

    @property
    def fallback_tap(self) -> tuple[int, int] | None:
        if self.fallback_tap_x is not None and self.fallback_tap_y is not None:
            return (self.fallback_tap_x, self.fallback_tap_y)
        return None


@dataclass
class SendBotConfig:
    """send-bot.com POST …/api/qr/payments/{id}/complete after device pay."""

    enabled: bool = False
    base_url: str = "https://send-bot.com"
    # Raw NextAuth session token, OR full Cookie header value (name=value[; …])
    session_cookie: str = ""
    nextauth_cookie_name: str = "__Secure-next-auth.session-token"
    account_key_name: str = "sh1"
    cr_account_id: str = ""
    cr_domain: str = "app.cr.bot"

    def cookie_header(self) -> str:
        """Build Cookie header: full string if multi-cookie or name=value; else prefix NextAuth name."""
        token = (os.environ.get("SEND_BOT_SESSION_COOKIE") or self.session_cookie or "").strip()
        if not token:
            return ""
        if ";" in token:
            return token
        parts = token.split(".")
        if len(parts) >= 3 and parts[0].startswith("ey"):
            name = (os.environ.get("SEND_BOT_COOKIE_NAME") or self.nextauth_cookie_name).strip()
            return f"{name}={token}"
        if "=" not in token:
            name = (os.environ.get("SEND_BOT_COOKIE_NAME") or self.nextauth_cookie_name).strip()
            return f"{name}={token}"
        return token

    def effective_cr_account_id(self) -> str:
        return (os.environ.get("SEND_BOT_CR_ACCOUNT_ID") or self.cr_account_id or "").strip()


@dataclass
class AppConfig:
    """Main application configuration."""

    accounts: list[AccountConfig] = field(default_factory=list)
    monitor: MonitorConfig = field(default_factory=MonitorConfig)
    adb: AdbConfig = field(default_factory=AdbConfig)
    elplat: ElplatConfig = field(default_factory=ElplatConfig)
    send_bot: SendBotConfig = field(default_factory=SendBotConfig)


class ConfigError(Exception):
    """Configuration loading error."""

    pass


def load_config(config_path: str | Path) -> AppConfig:
    """Load configuration from a TOML file."""
    path = Path(config_path)

    if not path.exists():
        raise ConfigError(f"Config file not found: {path}")

    try:
        with open(path, "rb") as f:
            data = tomllib.load(f)
    except tomllib.TOMLDecodeError as e:
        raise ConfigError(f"Invalid TOML syntax: {e}") from e

    monitor_data = data.get("monitor", {})
    monitor = MonitorConfig(
        poll_interval_seconds=monitor_data.get("poll_interval_seconds", 3),
    )

    adb_data = data.get("adb", {})
    adb = AdbConfig(
        serial=adb_data.get("serial", "") or "",
        binary=(adb_data.get("binary", "adb") or "adb").strip() or "adb",
    )

    elplat_data = data.get("elplat", {})
    elplat = ElplatConfig(
        wait_before_pay_seconds=float(elplat_data.get("wait_before_pay_seconds", 4.0)),
        fallback_tap_x=elplat_data.get("fallback_tap_x"),
        fallback_tap_y=elplat_data.get("fallback_tap_y"),
    )

    sb = data.get("send_bot", {})
    send_bot = SendBotConfig(
        enabled=bool(sb.get("enabled", False)),
        base_url=str(sb.get("base_url", "https://send-bot.com")).strip() or "https://send-bot.com",
        session_cookie=str(sb.get("session_cookie", "") or ""),
        nextauth_cookie_name=str(
            sb.get("nextauth_cookie_name", "__Secure-next-auth.session-token") or "__Secure-next-auth.session-token"
        ),
        account_key_name=str(sb.get("account_key_name", "sh1") or "sh1"),
        cr_account_id=str(sb.get("cr_account_id", "") or ""),
        cr_domain=str(sb.get("cr_domain", "app.cr.bot") or "app.cr.bot"),
    )

    accounts = []
    for acc_data in data.get("accounts", []):
        if "name" not in acc_data:
            raise ConfigError("Account missing 'name' field")
        if "access_token" not in acc_data:
            raise ConfigError(f"Account '{acc_data['name']}' missing 'access_token' field")

        accounts.append(
            AccountConfig(
                name=acc_data["name"],
                access_token=acc_data["access_token"],
            )
        )

    if not accounts:
        raise ConfigError("No accounts configured")

    return AppConfig(
        accounts=accounts,
        monitor=monitor,
        adb=adb,
        elplat=elplat,
        send_bot=send_bot,
    )
