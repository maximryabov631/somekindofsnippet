#!/usr/bin/env python3
"""
Test script for multiqr.ru / platiqr.ru deep link formats.
This helps diagnose and fix issues with opening payment links with amounts.
"""

import asyncio
import sys
from urllib.parse import urlparse, parse_qs, urlencode


async def test_deep_link(deep_link: str, description: str):
    """Test opening a deep link and see if it works."""
    print(f"\n{'='*80}")
    print(f"Testing: {description}")
    print(f"{'='*80}")
    print(f"Deep link: {deep_link}")
    
    input(f"\n▶️  Press Enter to open this link on device...")
    
    process = await asyncio.create_subprocess_exec(
        "adb", "shell", "am", "start",
        "-a", "android.intent.action.VIEW",
        "-d", deep_link,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE
    )
    stdout, stderr = await process.communicate()
    
    print(f"\nADB Output:")
    if stdout:
        print(stdout.decode('utf-8'))
    if stderr:
        print(f"Errors: {stderr.decode('utf-8')}")
    
    response = input("\n❓ Did it open with the correct amount? [y/n]: ")
    return response.lower() == 'y'


async def test_multiqr_formats(url: str):
    """Test different deep link formats for multiqr/platiqr."""
    
    print("="*80)
    print("🧪 MultiQR Deep Link Format Tester")
    print("="*80)
    
    # Parse the URL
    parsed = urlparse(url)
    query_params = parse_qs(parsed.query)
    
    print(f"\nOriginal URL: {url}")
    print(f"Domain: {parsed.netloc}")
    print(f"\nParsed parameters:")
    for key, value in query_params.items():
        print(f"  {key}: {value[0] if value else 'N/A'}")
    
    # Extract parameters
    uuid = query_params.get('uuid', [''])[0]
    trxid = query_params.get('trxid', [''])[0]
    payment_type = query_params.get('type', [''])[0]
    tips = query_params.get('tips', ['0.00'])[0]
    rating = query_params.get('rating', ['false'])[0]
    amount = query_params.get('amount', [None])[0]
    
    if not all([uuid, trxid, payment_type]):
        print("\n❌ Missing required parameters!")
        return
    
    print(f"\n📊 Key parameters:")
    print(f"  Amount: {amount or 'NOT SET'}")
    print(f"  UUID: {uuid}")
    print(f"  Transaction ID: {trxid}")
    
    # Test different formats
    formats = []
    
    # Format 1: Current implementation
    params1 = f"uuid={uuid}&trxid={trxid}&type={payment_type}&tips={tips}&rating={rating}&dn=multiqr"
    if amount:
        params1 += f"&amount={amount}"
    formats.append((
        f"yoomoney://multiqr.ru/?{params1}",
        "Current format (yoomoney://multiqr.ru/?params)"
    ))
    
    # Format 2: Without trailing slash
    params2 = f"uuid={uuid}&trxid={trxid}&type={payment_type}&tips={tips}&rating={rating}&dn=multiqr"
    if amount:
        params2 += f"&amount={amount}"
    formats.append((
        f"yoomoney://multiqr.ru?{params2}",
        "Without trailing slash"
    ))
    
    # Format 3: Using bank scheme
    params3 = f"uuid={uuid}&trxid={trxid}&type={payment_type}&tips={tips}&rating={rating}"
    if amount:
        params3 += f"&amount={amount}"
    formats.append((
        f"bank100000000022://multiqr.ru/?{params3}",
        "Bank scheme (bank100000000022://)"
    ))
    
    # Format 4: Full https URL (direct)
    formats.append((
        url,
        "Direct HTTPS URL (original)"
    ))
    
    # Format 5: With amount first
    if amount:
        params5 = f"amount={amount}&uuid={uuid}&trxid={trxid}&type={payment_type}&tips={tips}&rating={rating}&dn=multiqr"
        formats.append((
            f"yoomoney://multiqr.ru/?{params5}",
            "Amount parameter first"
        ))
    
    # Format 6: With sum instead of amount
    if amount:
        params6 = f"uuid={uuid}&trxid={trxid}&type={payment_type}&tips={tips}&rating={rating}&dn=multiqr&sum={amount}"
        formats.append((
            f"yoomoney://multiqr.ru/?{params6}",
            "Using 'sum' parameter instead of 'amount'"
        ))
    
    # Format 7: platiqr scheme
    if "platiqr" in parsed.netloc:
        params7 = f"uuid={uuid}&trxid={trxid}&type={payment_type}&tips={tips}&rating={rating}&dn=platiqr"
        if amount:
            params7 += f"&amount={amount}"
        formats.append((
            f"yoomoney://platiqr.ru/?{params7}",
            "Platiqr scheme"
        ))
    
    # Test each format
    print(f"\n📝 Will test {len(formats)} different formats\n")
    
    results = []
    for i, (deep_link, description) in enumerate(formats, 1):
        print(f"\n[Test {i}/{len(formats)}]")
        success = await test_deep_link(deep_link, description)
        results.append((description, deep_link, success))
        
        if success:
            print(f"✅ This format works!")
            confirm = input(f"\n❓ Stop testing and use this format? [y/n]: ")
            if confirm.lower() == 'y':
                break
        
        if i < len(formats):
            input(f"\n▶️  Press Enter to close YooMoney and continue to next test...")
            # Close YooMoney app
            await asyncio.create_subprocess_exec(
                "adb", "shell", "am", "force-stop", "ru.yoomoney.android.app",
                stdout=asyncio.subprocess.DEVNULL,
                stderr=asyncio.subprocess.DEVNULL
            )
            await asyncio.sleep(1)
    
    # Show results
    print("\n" + "="*80)
    print("📊 TEST RESULTS")
    print("="*80)
    
    for description, deep_link, success in results:
        status = "✅ WORKS" if success else "❌ FAILED"
        print(f"\n{status}: {description}")
        if success:
            print(f"   Link: {deep_link}")
    
    # Show recommendation
    working_formats = [r for r in results if r[2]]
    if working_formats:
        print("\n" + "="*80)
        print("💡 RECOMMENDATION")
        print("="*80)
        print(f"\nUse this format: {working_formats[0][0]}")
        print(f"Link: {working_formats[0][1]}")
        
        print("\n📝 I'll update the code to use this format.")
        confirm = input("\n▶️  Update handlers/yoomoney.py now? [y/n]: ")
        return working_formats[0][1] if confirm.lower() == 'y' else None
    else:
        print("\n❌ No working format found!")
        print("\nPossible issues:")
        print("  1. YooMoney app not installed")
        print("  2. Deep link handling not enabled in YooMoney")
        print("  3. Different deep link scheme needed")
        print("  4. Parameters might need different encoding")
        return None


async def main():
    """Main entry point."""
    
    # Check ADB connection
    process = await asyncio.create_subprocess_exec(
        "adb", "devices",
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE
    )
    stdout, _ = await process.communicate()
    devices = [line.split()[0] for line in stdout.decode('utf-8').strip().split('\n')[1:] if line.strip()]
    
    if not devices:
        print("❌ No devices connected!")
        print("   Connect device: adb connect 127.0.0.1:5555")
        return 1
    
    print(f"✅ Connected to: {devices[0]}")
    
    # Get URL from user
    print("\n" + "="*80)
    print("Enter a multiqr.ru or platiqr.ru URL to test")
    print("="*80)
    print("\nExample:")
    print("https://multiqr.ru/pay?uuid=XXX&trxid=YYY&type=ZZZ&amount=100.00")
    
    url = input("\n▶️  Enter URL: ").strip()
    
    if not url:
        print("❌ No URL provided")
        return 1
    
    # Validate URL
    parsed = urlparse(url)
    if "multiqr.ru" not in parsed.netloc and "platiqr.ru" not in parsed.netloc:
        print(f"❌ URL must be from multiqr.ru or platiqr.ru, got: {parsed.netloc}")
        return 1
    
    # Test formats
    working_link = await test_multiqr_formats(url)
    
    if working_link:
        print("\n✅ Testing complete! Use the recommended format above.")
    
    return 0


if __name__ == "__main__":
    sys.exit(asyncio.run(main()))

