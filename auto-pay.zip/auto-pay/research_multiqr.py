#!/usr/bin/env python3
"""
Deep research into multiqr.ru deep link formats.
Tests multiple hypotheses about how to pass amount correctly.
"""

import asyncio
import sys
from urllib.parse import urlparse, parse_qs, urlencode, quote, quote_plus


def analyze_url(url: str):
    """Analyze the original URL structure."""
    print("="*80)
    print("🔍 ANALYZING ORIGINAL URL")
    print("="*80)
    
    parsed = urlparse(url)
    query_params = parse_qs(parsed.query)
    
    print(f"\nFull URL: {url}")
    print(f"\nScheme: {parsed.scheme}")
    print(f"Domain: {parsed.netloc}")
    print(f"Path: {parsed.path}")
    print(f"Query: {parsed.query}")
    print(f"\nParsed Parameters:")
    
    for key, values in query_params.items():
        print(f"  {key}: {values[0] if values else 'N/A'}")
    
    return parsed, query_params


def generate_deep_link_variants(parsed, query_params):
    """Generate all possible deep link variants to test."""
    
    uuid = query_params.get('uuid', [''])[0]
    trxid = query_params.get('trxid', [''])[0]
    payment_type = query_params.get('type', ['sbp'])[0]
    tips = query_params.get('tips', ['0.00'])[0]
    rating = query_params.get('rating', ['false'])[0]
    amount = query_params.get('amount', [None])[0]
    
    domain = "platiqr" if "platiqr.ru" in parsed.netloc else "multiqr"
    
    variants = []
    
    # === HYPOTHESIS 1: Current implementation (amount at end) ===
    if amount:
        v1 = f"yoomoney://{domain}.ru/?uuid={uuid}&trxid={trxid}&type={payment_type}&tips={tips}&rating={rating}&dn={domain}&amount={amount}"
        variants.append(("Current (amount at end)", v1))
    
    # === HYPOTHESIS 2: Amount first ===
    if amount:
        v2 = f"yoomoney://{domain}.ru/?amount={amount}&uuid={uuid}&trxid={trxid}&type={payment_type}&tips={tips}&rating={rating}&dn={domain}"
        variants.append(("Amount first", v2))
    
    # === HYPOTHESIS 3: Without trailing slash ===
    if amount:
        v3 = f"yoomoney://{domain}.ru?uuid={uuid}&trxid={trxid}&type={payment_type}&tips={tips}&rating={rating}&dn={domain}&amount={amount}"
        variants.append(("No trailing slash", v3))
    
    # === HYPOTHESIS 4: Use 'sum' instead of 'amount' ===
    if amount:
        v4 = f"yoomoney://{domain}.ru/?uuid={uuid}&trxid={trxid}&type={payment_type}&tips={tips}&rating={rating}&dn={domain}&sum={amount}"
        variants.append(("Using 'sum' parameter", v4))
    
    # === HYPOTHESIS 5: Amount with currency ===
    if amount:
        v5 = f"yoomoney://{domain}.ru/?uuid={uuid}&trxid={trxid}&type={payment_type}&tips={tips}&rating={rating}&dn={domain}&amount={amount}&currency=RUB"
        variants.append(("Amount with currency", v5))
    
    # === HYPOTHESIS 6: Original HTTPS URL ===
    v6 = f"https://{domain}.ru{parsed.path}?{parsed.query}"
    variants.append(("Original HTTPS URL", v6))
    
    # === HYPOTHESIS 7: Bank scheme ===
    if amount:
        v7 = f"bank100000000022://{domain}.ru/?uuid={uuid}&trxid={trxid}&type={payment_type}&tips={tips}&rating={rating}&amount={amount}"
        variants.append(("Bank scheme", v7))
    
    # === HYPOTHESIS 8: Without dn parameter ===
    if amount:
        v8 = f"yoomoney://{domain}.ru/?uuid={uuid}&trxid={trxid}&type={payment_type}&tips={tips}&rating={rating}&amount={amount}"
        variants.append(("Without dn parameter", v8))
    
    # === HYPOTHESIS 9: Minimal parameters + amount ===
    if amount:
        v9 = f"yoomoney://{domain}.ru/?uuid={uuid}&trxid={trxid}&amount={amount}"
        variants.append(("Minimal params + amount", v9))
    
    # === HYPOTHESIS 10: URL encoded amount ===
    if amount:
        encoded_amount = quote(str(amount))
        v10 = f"yoomoney://{domain}.ru/?uuid={uuid}&trxid={trxid}&type={payment_type}&amount={encoded_amount}"
        variants.append(("URL encoded amount", v10))
    
    # === HYPOTHESIS 11: Using path instead of query ===
    if amount:
        v11 = f"yoomoney://{domain}.ru/pay/{uuid}/{trxid}/{amount}"
        variants.append(("Path-based routing", v11))
    
    # === HYPOTHESIS 12: Intent-based with extras ===
    if amount:
        v12 = f"intent://{domain}.ru/#Intent;scheme=https;action=android.intent.action.VIEW;S.uuid={uuid};S.trxid={trxid};S.amount={amount};end"
        variants.append(("Android Intent format", v12))
    
    # === HYPOTHESIS 13: Original URL with yoomoney scheme ===
    original_query = parsed.query
    v13 = f"yoomoney://{domain}.ru{parsed.path}?{original_query}"
    variants.append(("Original query preserved", v13))
    
    # === HYPOTHESIS 14: Amount in kopeks (cents) ===
    if amount:
        try:
            amount_kopeks = int(float(amount) * 100)
            v14 = f"yoomoney://{domain}.ru/?uuid={uuid}&trxid={trxid}&type={payment_type}&amount={amount_kopeks}"
            variants.append(("Amount in kopeks", v14))
        except:
            pass
    
    # === HYPOTHESIS 15: Using 'value' parameter ===
    if amount:
        v15 = f"yoomoney://{domain}.ru/?uuid={uuid}&trxid={trxid}&type={payment_type}&value={amount}"
        variants.append(("Using 'value' parameter", v15))
    
    return variants


async def test_variant(variant_name: str, deep_link: str, test_number: int, total: int):
    """Test a single deep link variant."""
    print(f"\n{'='*80}")
    print(f"TEST {test_number}/{total}: {variant_name}")
    print(f"{'='*80}")
    print(f"\nDeep link:")
    print(f"  {deep_link}")
    
    print(f"\n📱 This will open YooMoney app on your device...")
    response = input(f"▶️  Press Enter to test this variant (or 's' to skip): ")
    
    if response.lower() == 's':
        print("⏭️  Skipped")
        return None
    
    # Open the link
    process = await asyncio.create_subprocess_exec(
        "adb", "shell", "am", "start",
        "-a", "android.intent.action.VIEW",
        "-d", deep_link,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE
    )
    stdout, stderr = await process.communicate()
    
    if process.returncode != 0:
        error = stderr.decode('utf-8', errors='ignore')
        print(f"\n⚠️  ADB error: {error}")
    else:
        print(f"\n✅ Deep link opened")
    
    await asyncio.sleep(2)  # Let app open
    
    # Ask for user feedback
    print(f"\n" + "?"*80)
    print(f"CHECK YOUR DEVICE:")
    print(f"1. Did YooMoney app open?")
    print(f"2. Is the amount shown correctly on the payment screen?")
    print(f"3. Can you see the correct amount to pay?")
    print(f"?"*80)
    
    result = {}
    
    response = input(f"\n❓ Did it open with the CORRECT AMOUNT visible? [y/n/p]: ")
    if response.lower() == 'y':
        result['status'] = 'SUCCESS'
        result['note'] = input(f"📝 Any notes (press Enter to skip): ")
        print(f"\n🎉 SUCCESS! This format works!")
        return result
    elif response.lower() == 'p':
        result['status'] = 'PARTIAL'
        result['note'] = input(f"📝 What happened? (e.g. 'app opened but wrong amount'): ")
    else:
        result['status'] = 'FAILED'
        result['note'] = input(f"📝 What happened? (e.g. 'app didn't open', 'no amount shown'): ")
    
    # Close app for next test
    print(f"\n🔄 Closing YooMoney app for next test...")
    await asyncio.create_subprocess_exec(
        "adb", "shell", "am", "force-stop", "ru.yoomoney.android.app",
        stdout=asyncio.subprocess.DEVNULL,
        stderr=asyncio.subprocess.DEVNULL
    )
    await asyncio.sleep(1)
    
    return result


async def run_research(url: str):
    """Run comprehensive research on multiqr deep links."""
    
    print("\n")
    print("="*80)
    print("🔬 MULTIQR DEEP LINK RESEARCH")
    print("="*80)
    print("\nThis tool will test 15+ different deep link formats to find")
    print("which one correctly shows the amount in YooMoney app.")
    print("\n⚠️  Make sure:")
    print("  1. Android device is connected via ADB")
    print("  2. YooMoney app is installed")
    print("  3. You have the device nearby to check screens")
    
    input("\n▶️  Press Enter to continue...")
    
    # Analyze original URL
    parsed, query_params = analyze_url(url)
    
    # Check if amount is in URL
    amount = query_params.get('amount', [None])[0]
    if not amount:
        print(f"\n⚠️  WARNING: No 'amount' parameter found in URL!")
        print(f"   This might be why amount isn't showing.")
        print(f"   Available parameters: {list(query_params.keys())}")
        
        amount = input(f"\n❓ Enter amount to test manually (e.g. 100.00): ")
        if amount:
            query_params['amount'] = [amount]
    
    print(f"\n💰 Amount to test: {amount}")
    
    # Generate variants
    print(f"\n🧪 Generating test variants...")
    variants = generate_deep_link_variants(parsed, query_params)
    
    print(f"\n✅ Generated {len(variants)} variants to test\n")
    
    # Show all variants
    print("="*80)
    print("VARIANTS TO TEST:")
    print("="*80)
    for i, (name, link) in enumerate(variants, 1):
        print(f"\n{i}. {name}")
        print(f"   {link[:100]}{'...' if len(link) > 100 else ''}")
    
    input(f"\n▶️  Press Enter to start testing...")
    
    # Test each variant
    results = []
    for i, (name, link) in enumerate(variants, 1):
        result = await test_variant(name, link, i, len(variants))
        results.append((name, link, result))
        
        if result and result.get('status') == 'SUCCESS':
            print(f"\n🎯 FOUND WORKING FORMAT!")
            save = input(f"\n▶️  Stop testing and use this format? [y/n]: ")
            if save.lower() == 'y':
                break
    
    # Summary
    print(f"\n{'='*80}")
    print(f"📊 RESEARCH SUMMARY")
    print(f"{'='*80}\n")
    
    successful = []
    partial = []
    failed = []
    
    for name, link, result in results:
        if result is None:
            continue
        
        status = result.get('status', 'UNKNOWN')
        if status == 'SUCCESS':
            successful.append((name, link, result))
        elif status == 'PARTIAL':
            partial.append((name, link, result))
        else:
            failed.append((name, link, result))
    
    if successful:
        print(f"✅ SUCCESSFUL FORMATS ({len(successful)}):")
        for name, link, result in successful:
            print(f"\n  ✓ {name}")
            print(f"    Link: {link}")
            if result.get('note'):
                print(f"    Note: {result['note']}")
    
    if partial:
        print(f"\n⚠️  PARTIAL SUCCESS ({len(partial)}):")
        for name, link, result in partial:
            print(f"\n  ~ {name}")
            print(f"    Note: {result.get('note', 'No details')}")
    
    if failed:
        print(f"\n❌ FAILED FORMATS ({len(failed)}):")
        for name, link, result in failed:
            print(f"\n  ✗ {name}")
            print(f"    Reason: {result.get('note', 'No details')}")
    
    # Recommendation
    if successful:
        print(f"\n{'='*80}")
        print(f"💡 RECOMMENDATION")
        print(f"{'='*80}\n")
        
        best = successful[0]
        print(f"Use this format: {best[0]}")
        print(f"\nFull link: {best[1]}")
        
        print(f"\n📝 TO IMPLEMENT:")
        print(f"Update handlers/yoomoney.py in _build_deep_link() method")
        print(f"around line 214-227 to use this format.")
        
        update = input(f"\n▶️  Show code to implement this? [y/n]: ")
        if update.lower() == 'y':
            show_implementation_code(best[0], best[1], parsed, query_params)
    else:
        print(f"\n❌ No successful format found.")
        print(f"\nPossible issues:")
        print(f"  1. Original URL doesn't contain amount parameter")
        print(f"  2. YooMoney app version doesn't support deep links with amount")
        print(f"  3. Need to use manual amount input method instead")
        print(f"  4. Amount is passed after opening (not in deep link)")


def show_implementation_code(variant_name: str, successful_link: str, parsed, query_params):
    """Show code to implement the successful variant."""
    
    print(f"\n{'='*80}")
    print(f"📝 IMPLEMENTATION CODE")
    print(f"{'='*80}\n")
    
    domain = "platiqr" if "platiqr.ru" in parsed.netloc else "multiqr"
    
    # Analyze the successful link structure
    if "yoomoney://" in successful_link and "amount=" in successful_link:
        if successful_link.index("amount=") < successful_link.index("uuid="):
            position = "FIRST"
        else:
            position = "LAST"
    else:
        position = "UNKNOWN"
    
    print("Replace the multiqr section in _build_deep_link():")
    print("\n```python")
    print('elif "multiqr.ru" in parsed.netloc or "platiqr.ru" in parsed.netloc:')
    print('    query_params = parse_qs(parsed.query)')
    print('')
    print("    uuid = query_params.get('uuid', [''])[0]")
    print("    trxid = query_params.get('trxid', [''])[0]")
    print("    payment_type = query_params.get('type', [''])[0]")
    print("    tips = query_params.get('tips', ['0.00'])[0]")
    print("    rating = query_params.get('rating', ['false'])[0]")
    print("    amount = query_params.get('amount', [None])[0]")
    print('')
    print('    domain = "platiqr" if "platiqr.ru" in parsed.netloc else "multiqr"')
    print('')
    
    if variant_name == "Original HTTPS URL":
        print("    # Use original HTTPS URL (browser redirect)")
        print("    return url")
    
    elif "Amount first" in variant_name:
        print("    # Build with amount first")
        print("    deep_link = (")
        print('        f"yoomoney://{domain}.ru/"')
        print('        f"?amount={amount or \'\'}"')
        print('        f"&uuid={uuid}&trxid={trxid}&type={payment_type}"')
        print('        f"&tips={tips}&rating={rating}&dn={domain}"')
        print("    )")
    
    elif "sum" in variant_name:
        print("    # Use 'sum' parameter instead of 'amount'")
        print("    deep_link = (")
        print('        f"yoomoney://{domain}.ru/"')
        print('        f"?uuid={uuid}&trxid={trxid}&type={payment_type}"')
        print('        f"&tips={tips}&rating={rating}&dn={domain}"')
        print("    )")
        print("    if amount:")
        print('        deep_link += f"&sum={amount}"')
    
    elif "No trailing slash" in variant_name:
        print("    # No trailing slash after domain")
        print("    deep_link = (")
        print('        f"yoomoney://{domain}.ru"')
        print('        f"?uuid={uuid}&trxid={trxid}&type={payment_type}"')
        print('        f"&tips={tips}&rating={rating}&dn={domain}"')
        print("    )")
        print("    if amount:")
        print('        deep_link += f"&amount={amount}"')
    
    else:
        print("    # Use format that worked")
        print("    deep_link = (")
        print('        f"yoomoney://{domain}.ru/"')
        print('        f"?uuid={uuid}&trxid={trxid}&type={payment_type}"')
        print('        f"&tips={tips}&rating={rating}&dn={domain}"')
        print("    )")
        print("    if amount:")
        print('        deep_link += f"&amount={amount}"')
    
    print('')
    print("    return deep_link")
    print("```")


async def main():
    """Main entry point."""
    
    # Check ADB connection
    process = await asyncio.create_subprocess_exec(
        "adb", "devices",
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE
    )
    stdout, _ = await process.communicate()
    devices = [line.split()[0] for line in stdout.decode('utf-8').strip().split('\n')[1:] if line.strip()]
    
    if not devices:
        print("❌ No ADB devices connected!")
        print("   Connect device: adb connect 127.0.0.1:5555")
        return 1
    
    print(f"✅ Connected to: {devices[0]}")
    
    # Get URL from user
    print(f"\n{'='*80}")
    print("ENTER MULTIQR/PLATIQR URL TO RESEARCH")
    print(f"{'='*80}")
    print("\nProvide a real multiqr.ru or platiqr.ru payment URL with amount.")
    print("\nExample:")
    print("https://multiqr.ru/pay?uuid=XXX&trxid=YYY&type=sbp&amount=100.00")
    
    url = input("\n▶️  Enter URL: ").strip()
    
    if not url:
        print("❌ No URL provided")
        return 1
    
    # Validate
    if "multiqr.ru" not in url and "platiqr.ru" not in url:
        print(f"❌ URL must be from multiqr.ru or platiqr.ru")
        return 1
    
    # Run research
    await run_research(url)
    
    print(f"\n{'='*80}")
    print("🎓 Research complete!")
    print(f"{'='*80}\n")
    
    return 0


if __name__ == "__main__":
    sys.exit(asyncio.run(main()))





