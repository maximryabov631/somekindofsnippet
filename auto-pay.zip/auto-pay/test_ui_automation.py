#!/usr/bin/env python3
"""
Test script for UI automation on connected Android devices.
Tests the device-independent element finding.
"""

import asyncio
import sys
import xml.etree.ElementTree as ET
import re


async def test_adb_connection():
    """Test if ADB is connected to a device."""
    print("🔌 Testing ADB connection...")
    
    process = await asyncio.create_subprocess_exec(
        "adb", "devices",
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE
    )
    stdout, stderr = await process.communicate()
    
    output = stdout.decode('utf-8')
    lines = output.strip().split('\n')[1:]  # Skip header
    devices = [line.split()[0] for line in lines if line.strip()]
    
    if not devices:
        print("❌ No devices connected!")
        print("   For LDPlayer: adb connect 127.0.0.1:5555")
        print("   For Phone: Enable USB debugging and connect via USB")
        return False
    
    print(f"✅ Connected devices: {', '.join(devices)}")
    return True


async def get_ui_dump():
    """Get UI hierarchy from device."""
    print("\n📱 Capturing screen UI...")
    
    try:
        # Dump UI to file on device
        dump_path = "/sdcard/window_dump.xml"
        
        # Create dump file
        process = await asyncio.create_subprocess_exec(
            "adb", "shell", "uiautomator", "dump", dump_path,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE
        )
        stdout, stderr = await process.communicate()
        
        # Check for errors
        if process.returncode != 0:
            error_msg = stderr.decode('utf-8', errors='ignore')
            print(f"❌ UI dump command failed: {error_msg}")
            return None
        
        # Small delay to ensure file is written
        await asyncio.sleep(0.2)
        
        # Read the dump file
        process = await asyncio.create_subprocess_exec(
            "adb", "shell", "cat", dump_path,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE
        )
        stdout, stderr = await process.communicate()
        
        xml_content = stdout.decode('utf-8', errors='ignore')
        
        # Clean up
        await asyncio.create_subprocess_exec(
            "adb", "shell", "rm", dump_path,
            stdout=asyncio.subprocess.DEVNULL,
            stderr=asyncio.subprocess.DEVNULL
        )
        
        if '<hierarchy' in xml_content:
            print("✅ UI dump captured successfully")
            # Show file size
            size_kb = len(xml_content) / 1024
            print(f"   Dump size: {size_kb:.1f} KB")
            return xml_content
        else:
            print("❌ Failed to capture UI dump - no valid XML found")
            if xml_content:
                print(f"   Got: {xml_content[:200]}...")
            return None
            
    except Exception as e:
        print(f"❌ Error capturing UI dump: {e}")
        return None


async def get_screen_resolution():
    """Get device screen resolution."""
    process = await asyncio.create_subprocess_exec(
        "adb", "shell", "wm", "size",
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE
    )
    stdout, _ = await process.communicate()
    output = stdout.decode('utf-8').strip()
    
    if 'Physical size:' in output:
        resolution = output.split(':')[1].strip()
        print(f"📐 Screen resolution: {resolution}")
        return resolution
    return "Unknown"


def parse_bounds(bounds_str):
    """Parse bounds to get center coordinates."""
    match = re.match(r'\[(\d+),(\d+)\]\[(\d+),(\d+)\]', bounds_str)
    if match:
        x1, y1, x2, y2 = map(int, match.groups())
        center_x = (x1 + x2) // 2
        center_y = (y1 + y2) // 2
        return {'x': center_x, 'y': center_y}
    return None


def analyze_ui_dump(xml_content):
    """Analyze the UI dump and show clickable elements."""
    print("\n🔍 Analyzing UI elements...\n")
    
    try:
        root = ET.fromstring(xml_content)
        
        clickable_count = 0
        buttons = []
        
        for node in root.iter('node'):
            clickable = node.get('clickable', 'false') == 'true'
            if clickable:
                clickable_count += 1
                
                text = node.get('text', '')
                content_desc = node.get('content-desc', '')
                class_name = node.get('class', '')
                bounds = node.get('bounds', '')
                
                if text or content_desc:
                    coords = parse_bounds(bounds)
                    buttons.append({
                        'text': text or content_desc,
                        'class': class_name.split('.')[-1],
                        'coords': coords,
                        'bounds': bounds
                    })
        
        print(f"Total clickable elements: {clickable_count}")
        print(f"Buttons with text: {len(buttons)}\n")
        
        if buttons:
            print("📋 Found buttons:")
            print("-" * 80)
            for i, btn in enumerate(buttons[:20], 1):  # Show first 20
                coords = btn['coords']
                coord_str = f"({coords['x']}, {coords['y']})" if coords else "N/A"
                print(f"{i:2d}. [{btn['class']:20s}] {btn['text'][:40]:40s} → {coord_str}")
            
            if len(buttons) > 20:
                print(f"\n... and {len(buttons) - 20} more buttons")
        else:
            print("⚠️  No buttons with text found. Make sure an app is open.")
        
        return len(buttons) > 0
        
    except Exception as e:
        print(f"❌ Error parsing UI dump: {e}")
        return False


async def test_yoomoney_buttons(xml_content):
    """Test finding YooMoney-specific buttons."""
    print("\n🎯 Testing YooMoney button detection...\n")
    
    try:
        root = ET.fromstring(xml_content)
        
        search_texts = [
            ["Продолжить", "Continue", "Далее"],
            ["Заплатить", "Pay", "Оплатить", "Подтвердить"]
        ]
        
        for button_group in search_texts:
            print(f"Searching for: {' / '.join(button_group)}")
            
            found = False
            for node in root.iter('node'):
                clickable = node.get('clickable', 'false') == 'true'
                if not clickable:
                    continue
                
                node_text = node.get('text', '')
                content_desc = node.get('content-desc', '')
                
                for search_text in button_group:
                    if (search_text.lower() in node_text.lower() or 
                        search_text.lower() in content_desc.lower()):
                        
                        bounds = node.get('bounds')
                        coords = parse_bounds(bounds)
                        
                        if coords:
                            print(f"  ✅ Found '{node_text or content_desc}' at ({coords['x']}, {coords['y']})")
                            found = True
                            break
                
                if found:
                    break
            
            if not found:
                print(f"  ℹ️  Not found (expected if YooMoney is not open)")
        
    except Exception as e:
        print(f"❌ Error: {e}")


async def main():
    """Main test function."""
    print("=" * 80)
    print("🧪 UI Automation Test for Auto-Pay")
    print("=" * 80)
    
    # Test 1: ADB connection
    if not await test_adb_connection():
        return 1
    
    # Test 2: Screen resolution
    await get_screen_resolution()
    
    # Test 3: Get UI dump
    ui_dump = await get_ui_dump()
    if not ui_dump:
        return 1
    
    # Test 4: Analyze UI
    has_buttons = analyze_ui_dump(ui_dump)
    
    # Test 5: YooMoney-specific tests
    await test_yoomoney_buttons(ui_dump)
    
    print("\n" + "=" * 80)
    print("✅ Test completed!")
    print("\n💡 Tips:")
    print("   - Open YooMoney app and run this again to see payment buttons")
    print("   - The system will now work on ANY device with ANY resolution")
    print("   - Switch devices freely - no configuration needed!")
    print("=" * 80)
    
    return 0


if __name__ == "__main__":
    sys.exit(asyncio.run(main()))

