#!/usr/bin/env python3
"""
Quick diagnostic to check what URLs the API actually provides.
This helps understand if the amount is even in the source URL.
"""

import asyncio
import sys
from pathlib import Path
from urllib.parse import urlparse, parse_qs

sys.path.insert(0, str(Path(__file__).parent))

from config import load_config
from api.client import P2CClient


async def check_payment_urls():
    """Check recent payment URLs to see their structure."""
    
    print("="*80)
    print("🔍 PAYMENT URL DIAGNOSTIC")
    print("="*80)
    print("\nThis tool checks the actual URLs provided by the payment API")
    print("to see if they contain amount parameters.\n")
    
    # Load config
    try:
        config = load_config("config.toml")
    except Exception as e:
        print(f"❌ Failed to load config: {e}")
        return 1
    
    if not config.accounts:
        print("❌ No accounts configured")
        return 1
    
    account = config.accounts[0]
    print(f"✅ Using account: {account.name}\n")
    
    # Connect to API
    client = P2CClient(account.access_token)
    
    try:
        print("📡 Fetching payments from API...")
        payments = await client.get_payments()
        
        if not payments:
            print("⚠️  No payments found")
            return 0
        
        print(f"✅ Found {len(payments)} payment(s)\n")
        
        # Analyze each payment
        multiqr_count = 0
        
        for i, payment in enumerate(payments[:10], 1):  # Check last 10
            print(f"{'='*80}")
            print(f"PAYMENT #{i}")
            print(f"{'='*80}")
            print(f"ID: {payment.id}")
            print(f"Status: {payment.status.value}")
            print(f"Amount: {payment.out_amount} {payment.out_asset}")
            print(f"Brand: {payment.brand_name}")
            
            if not payment.url:
                print(f"URL: None ❌")
                continue
            
            print(f"\nURL: {payment.url}")
            
            # Parse URL
            parsed = urlparse(payment.url)
            print(f"\nDomain: {parsed.netloc}")
            print(f"Path: {parsed.path}")
            print(f"Query: {parsed.query}")
            
            # Check if it's multiqr/platiqr
            if "multiqr.ru" in parsed.netloc or "platiqr.ru" in parsed.netloc:
                multiqr_count += 1
                print(f"\n🎯 This is a MultiQR/PlatiQR payment!")
                
                # Parse query parameters
                params = parse_qs(parsed.query)
                print(f"\nParameters:")
                for key, values in params.items():
                    print(f"  {key}: {values[0] if values else 'N/A'}")
                
                # Check for amount
                if 'amount' in params:
                    amount_param = params['amount'][0]
                    print(f"\n✅ Amount found in URL: {amount_param}")
                    
                    # Compare with payment amount
                    if str(payment.out_amount) == str(amount_param):
                        print(f"   ✓ Matches payment amount!")
                    else:
                        print(f"   ⚠️  Differs from payment amount: {payment.out_amount}")
                else:
                    print(f"\n❌ NO 'amount' parameter in URL!")
                    print(f"   Expected amount: {payment.out_amount} {payment.out_asset}")
                    print(f"   This is why amount doesn't show in YooMoney!")
                    
                    # Check for alternative parameter names
                    alt_params = ['sum', 'value', 'price', 'total']
                    found_alt = False
                    for alt in alt_params:
                        if alt in params:
                            print(f"   ℹ️  Found '{alt}' parameter: {params[alt][0]}")
                            found_alt = True
                    
                    if not found_alt:
                        print(f"   💡 Solution: Use manual amount input")
                        print(f"      or get amount from payment.out_amount")
            
            print()
        
        # Summary
        print(f"{'='*80}")
        print(f"📊 SUMMARY")
        print(f"{'='*80}\n")
        
        if multiqr_count == 0:
            print(f"⚠️  No MultiQR/PlatiQR payments found in recent payments")
            print(f"   Wait for a MultiQR payment or provide URL manually to research tool")
        else:
            print(f"✅ Found {multiqr_count} MultiQR/PlatiQR payment(s)")
            print(f"\n💡 Next steps:")
            print(f"   1. If URL has 'amount' parameter:")
            print(f"      → Run: python3 research_multiqr.py")
            print(f"      → Test different deep link formats")
            print(f"   ")
            print(f"   2. If URL has NO 'amount' parameter:")
            print(f"      → Manual input is the only option")
            print(f"      → Use Elplat SBP flow or manual amount in your bank app")
            print(f"      → System will auto-fill amount field")
    
    except Exception as e:
        print(f"❌ Error: {e}")
        import traceback
        traceback.print_exc()
        return 1
    
    finally:
        await client.close()
    
    return 0


async def main():
    """Main entry point."""
    return await check_payment_urls()


if __name__ == "__main__":
    sys.exit(asyncio.run(main()))





