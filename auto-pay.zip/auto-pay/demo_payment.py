#!/usr/bin/env python3
"""
Demo: test Elplat SBP auto-payment with a qr.nspk.ru link (no P2C API).
"""

import asyncio
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

from api.types import PaymentDetails
from handlers.elplat import ElplatHandler


async def demo_payment() -> int:
    print("=" * 80)
    print("Elplat SBP auto-payment demo")
    print("=" * 80)

    print("\n1. Checking adb devices...")
    process = await asyncio.create_subprocess_exec(
        "adb",
        "devices",
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
    )
    stdout, _ = await process.communicate()
    lines = [ln for ln in stdout.decode("utf-8", errors="ignore").strip().split("\n")[1:] if ln.strip()]
    devices = [ln.split()[0] for ln in lines]
    if not devices:
        print("No devices. Example: adb connect 127.0.0.1:5555")
        return 1
    print(f"OK: {', '.join(devices)}")

    qr_url = "https://qr.nspk.ru/AD10003SUOP2VLJG8BPA8LS6L1MJRA6R"
    payment = PaymentDetails(
        id=0,
        url=qr_url,
        brand_name="Demo",
        out_amount="100.00",
        out_asset="RUB",
    )
    handler = ElplatHandler()
    if not await handler.can_handle(payment):
        print("Handler cannot process this URL")
        return 1

    print("\n" + "=" * 80)
    print("This will open Elplat and attempt to tap the pay button.")
    if input("\nContinue? [y/N]: ").lower() != "y":
        print("Cancelled.")
        return 0

    ok = await handler.auto_pay(payment)
    print("\n", "OK" if ok else "FAIL")
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(asyncio.run(demo_payment()))
