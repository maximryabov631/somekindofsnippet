import asyncio
import logging
import re
import xml.etree.ElementTree as ET
from urllib.parse import urlparse

from api.types import PaymentDetails

from .base import BankHandler

logger = logging.getLogger(__name__)

# Elplat / SBP app scheme for qr.nspk.ru (NSPK QR)
ELPLAT_SCHEME = "bank100000000086"


class ElplatHandler(BankHandler):
    """ADB handler for Elplat SBP payments (qr.nspk.ru)."""

    BAD_KEYWORDS: list[str] = []

    def __init__(
        self,
        adb_serial: str = "",
        adb_binary: str = "adb",
        wait_before_pay_seconds: float = 4.0,
        fallback_tap: tuple[int, int] | None = None,
    ):
        self._adb_bin = (adb_binary or "adb").strip() or "adb"
        self._adb_prefix = (
            [self._adb_bin, "-s", adb_serial] if adb_serial else [self._adb_bin]
        )
        self._wait_before_pay = wait_before_pay_seconds
        self._fallback_tap = fallback_tap

    @property
    def name(self) -> str:
        return "Elplat"

    async def can_handle(self, payment: PaymentDetails) -> bool:
        if not payment.url:
            return False
        if "qr.nspk.ru" not in payment.url.lower():
            return False
        brand = payment.brand_name or ""
        return not self._has_bad_keyword(brand)

    async def auto_pay(self, payment: PaymentDetails) -> bool:
        logger.info(
            f"[{self.name}] Auto-pay triggered for payment {payment.id}, "
            f"amount: {payment.out_amount} {payment.out_asset}"
        )

        if not payment.url:
            logger.error(f"[{self.name}] No payment URL provided")
            return False

        try:
            await self._ensure_adb()

            deep_link = self._build_deep_link(payment.url)
            if not deep_link:
                logger.error(f"[{self.name}] Failed to build deep link from URL: {payment.url}")
                return False

            logger.info(f"[{self.name}] Opening deep link: {deep_link}")

            open_cmd = [
                *self._adb_prefix,
                "shell",
                "am",
                "start",
                "-a",
                "android.intent.action.VIEW",
                "-d",
                deep_link,
                "--activity-clear-top",
            ]
            process = await asyncio.create_subprocess_exec(
                *open_cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            stdout, stderr = await process.communicate()
            combined = (stdout.decode("utf-8", errors="ignore") + stderr.decode("utf-8", errors="ignore"))

            if process.returncode != 0 or "Error" in combined:
                logger.error(f"[{self.name}] Intent failed: {combined.strip() or process.returncode}")
                return False

            logger.info(f"[{self.name}] Waiting {self._wait_before_pay}s for payment screen...")
            await asyncio.sleep(self._wait_before_pay)

            logger.info(f"[{self.name}] Looking for pay button (ОПЛАТИТЬ / Оплатить / …)")
            ui_dump = await self._get_ui_dump()
            pay_btn = None
            if ui_dump:
                pay_btn = await self._find_button_by_text_cached(
                    [
                        "ОПЛАТИТЬ",
                        "Оплатить",
                        "Заплатить",
                        "Pay",
                        "Подтвердить",
                    ],
                    ui_dump,
                )

            if pay_btn:
                if not await self._tap_element(pay_btn):
                    logger.error(f"[{self.name}] Tap on pay button failed")
                    return False
            elif self._fallback_tap:
                fx, fy = self._fallback_tap
                logger.warning(f"[{self.name}] Pay button not found, using fallback tap ({fx}, {fy})")
                if not await self._tap_xy(fx, fy):
                    return False
            else:
                logger.error(f"[{self.name}] Pay button not found and no fallback_tap configured")
                return False

            logger.info(f"[{self.name}] Auto-pay sequence completed")
            return True

        except Exception as e:
            logger.exception(f"[{self.name}] Error during auto-pay: {e}")
            return False

    def _build_deep_link(self, url: str) -> str | None:
        try:
            raw = url.strip()
            if raw.startswith("bank") and "://" in raw:
                return raw

            if not raw.startswith(("http://", "https://")):
                raw = f"https://qr.nspk.ru/{raw}"

            parsed = urlparse(raw)
            if "qr.nspk.ru" not in parsed.netloc.lower():
                logger.error(f"[{self.name}] Expected qr.nspk.ru host, got: {parsed.netloc}")
                return None

            path = parsed.path.lstrip("/")
            if not path:
                logger.error(f"[{self.name}] Missing path / token in URL")
                return None

            return f"{ELPLAT_SCHEME}://qr.nspk.ru/{path}"
        except Exception as e:
            logger.exception(f"[{self.name}] Error building deep link: {e}")
            return None

    async def _ensure_adb(self) -> None:
        await asyncio.create_subprocess_exec(
            self._adb_bin,
            "start-server",
            stdout=asyncio.subprocess.DEVNULL,
            stderr=asyncio.subprocess.DEVNULL,
        )
        if len(self._adb_prefix) >= 3 and self._adb_prefix[:2] == [self._adb_bin, "-s"]:
            serial = self._adb_prefix[2]
            if re.match(r"^[\d.]+:\d+$", serial):
                proc = await asyncio.create_subprocess_exec(
                    self._adb_bin,
                    "connect",
                    serial,
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE,
                )
                out, _ = await proc.communicate()
                logger.debug(f"[{self.name}] adb connect {serial}: {out.decode(errors='ignore').strip()}")
                wait = await asyncio.create_subprocess_exec(
                    *self._adb_prefix,
                    "wait-for-device",
                    stdout=asyncio.subprocess.DEVNULL,
                    stderr=asyncio.subprocess.DEVNULL,
                )
                await wait.communicate()

    async def _get_ui_dump(self) -> str | None:
        dump_path = "/sdcard/window_dump_elplat.xml"
        try:
            dump_process = await asyncio.create_subprocess_exec(
                *self._adb_prefix,
                "shell",
                "uiautomator",
                "dump",
                dump_path,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            await dump_process.communicate()
            await asyncio.sleep(0.05)

            read_proc = await asyncio.create_subprocess_exec(
                *self._adb_prefix,
                "shell",
                "cat",
                dump_path,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            stdout, _ = await read_proc.communicate()
            xml_content = stdout.decode("utf-8", errors="ignore")

            asyncio.create_task(
                asyncio.create_subprocess_exec(
                    *self._adb_prefix,
                    "shell",
                    "rm",
                    dump_path,
                    stdout=asyncio.subprocess.DEVNULL,
                    stderr=asyncio.subprocess.DEVNULL,
                )
            )

            if "<hierarchy" in xml_content:
                return xml_content
            logger.warning(f"[{self.name}] No valid XML in UI dump")
            return None
        except Exception as e:
            logger.exception(f"[{self.name}] Error getting UI dump: {e}")
            return None

    async def _find_button_by_text_cached(self, texts: list[str], ui_xml: str) -> dict | None:
        try:
            root = ET.fromstring(ui_xml)
            for node in root.iter("node"):
                if node.get("clickable", "false") != "true":
                    continue
                node_text = node.get("text", "")
                content_desc = node.get("content-desc", "")
                for search_text in texts:
                    if search_text.lower() in node_text.lower() or search_text.lower() in content_desc.lower():
                        bounds = node.get("bounds")
                        coords = self._parse_bounds(bounds)
                        if coords:
                            logger.info(
                                f"[{self.name}] Found button '{node_text or content_desc}' at {coords}"
                            )
                            return coords
            logger.warning(f"[{self.name}] Button not found with texts: {texts}")
            return None
        except Exception as e:
            logger.exception(f"[{self.name}] Error finding button: {e}")
            return None

    def _parse_bounds(self, bounds_str: str) -> dict | None:
        try:
            match = re.match(r"\[(\d+),(\d+)\]\[(\d+),(\d+)\]", bounds_str)
            if match:
                x1, y1, x2, y2 = map(int, match.groups())
                return {"x": (x1 + x2) // 2, "y": (y1 + y2) // 2}
            return None
        except Exception as e:
            logger.error(f"[{self.name}] Error parsing bounds '{bounds_str}': {e}")
            return None

    async def _tap_element(self, element: dict) -> bool:
        try:
            return await self._tap_xy(element["x"], element["y"])
        except Exception as e:
            logger.exception(f"[{self.name}] Tap error: {e}")
            return False

    async def _tap_xy(self, x: int, y: int) -> bool:
        process = await asyncio.create_subprocess_exec(
            *self._adb_prefix,
            "shell",
            "input",
            "tap",
            str(x),
            str(y),
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        await process.communicate()
        logger.info(f"[{self.name}] Tapped at ({x}, {y})")
        return process.returncode == 0
