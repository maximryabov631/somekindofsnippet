from abc import ABC, abstractmethod

from api.types import PaymentDetails


class BankHandler(ABC):
    """Abstract base class for bank-specific ADB handlers."""

    # Override in subclasses
    BAD_KEYWORDS: list[str] = []

    def _has_bad_keyword(self, brand_name: str) -> bool:
        """Check if brand_name contains any bad keyword (case-insensitive)."""
        if not brand_name:
            return False
        brand_lower = brand_name.lower()
        return any(kw in brand_lower for kw in self.BAD_KEYWORDS)

    @property
    @abstractmethod
    def name(self) -> str:
        """Handler name for logging."""
        pass

    @abstractmethod
    async def can_handle(self, payment: PaymentDetails) -> bool:
        """Check if this handler can process the given payment.

        Args:
            payment: Payment details from the API.

        Returns:
            True if this handler supports the payment's bank/provider.
        """
        pass

    @abstractmethod
    async def auto_pay(self, payment: PaymentDetails) -> bool:
        """Execute ADB auto-pay for the given payment.

        Args:
            payment: Payment details including bank account info.

        Returns:
            True if payment was successful, False otherwise.
        """
        pass
