import asyncio
import logging
from typing import TYPE_CHECKING, Optional

from api.client import P2CClient, P2CClientError
from api.types import PaymentStatus
from config import AccountConfig
from handlers import ElplatHandler

if TYPE_CHECKING:
    from api.send_bot import SendBotClient

logger = logging.getLogger(__name__)


class PaymentMonitor:
    """Monitors a P2C account for new payments, opens Elplat SBP, taps pay, then send-bot complete."""

    def __init__(
        self,
        account: AccountConfig,
        poll_interval: int = 3,
        elplat_wait_before_pay_seconds: float = 4.0,
        elplat_fallback_tap: tuple[int, int] | None = None,
        adb_serial: str = "",
        adb_binary: str = "adb",
        send_bot: Optional["SendBotClient"] = None,
    ):
        self.account = account
        self.poll_interval = poll_interval
        self.client = P2CClient(account.access_token)
        self.seen_payments: set[int] = set()
        self.processing_payments: set[int] = set()
        self._running = False
        self.send_bot = send_bot
        self._handler = ElplatHandler(
            adb_serial=adb_serial or "",
            adb_binary=adb_binary or "adb",
            wait_before_pay_seconds=elplat_wait_before_pay_seconds,
            fallback_tap=elplat_fallback_tap,
        )

    async def start(self) -> None:
        """Start the payment monitoring loop."""
        self._running = True
        logger.info(f"[{self.account.name}] Starting payment monitor (Elplat SBP)")

        try:
            await self._fetch_initial_payments()

            while self._running:
                try:
                    await self._check_payments()
                except P2CClientError as e:
                    logger.error(f"[{self.account.name}] API error: {e}")
                except Exception as e:
                    logger.exception(f"[{self.account.name}] Unexpected error: {e}")

                await asyncio.sleep(self.poll_interval)

        finally:
            await self.client.close()
            logger.info(f"[{self.account.name}] Payment monitor stopped")

    def stop(self) -> None:
        """Signal the monitor to stop."""
        self._running = False
        logger.info(f"[{self.account.name}] Stopping payment monitor...")

    async def _fetch_initial_payments(self) -> None:
        """Fetch existing payments to avoid triggering on old orders."""
        logger.info(f"[{self.account.name}] Fetching initial payments...")

        try:
            payments = await self.client.get_payments()
            for payment in payments:
                self.seen_payments.add(payment.id)
                if payment.status == PaymentStatus.PROCESSING:
                    self.processing_payments.add(payment.id)

            logger.info(
                f"[{self.account.name}] Found {len(payments)} existing payments, "
                f"{len(self.processing_payments)} processing"
            )
        except P2CClientError as e:
            logger.error(f"[{self.account.name}] Failed to fetch initial payments: {e}")

    async def _check_payments(self) -> None:
        """Check for new payments and process them."""
        payments = await self.client.get_payments()

        for payment in payments:
            if payment.id in self.seen_payments:
                if payment.id in self.processing_payments:
                    if payment.status != PaymentStatus.PROCESSING:
                        self._log_status_change(payment.id, payment.status)
                        self.processing_payments.discard(payment.id)
                continue

            self.seen_payments.add(payment.id)
            logger.info(
                f"[{self.account.name}] New payment detected: "
                f"id={payment.id}, status={payment.status.value}, "
                f"amount={payment.amount_fiat} {payment.fiat}"
            )

            if payment.status == PaymentStatus.PROCESSING:
                self.processing_payments.add(payment.id)
                await self._process_payment(payment.id)

    async def _process_payment(self, payment_id: int) -> None:
        """Fetch payment details, Elplat auto-pay, then send-bot complete."""
        logger.info(f"[{self.account.name}] Processing payment {payment_id}...")

        details = await self.client.get_payment_by_id(payment_id)
        if not details:
            logger.error(f"[{self.account.name}] Failed to fetch payment details for {payment_id}")
            return

        if details.url:
            logger.info(f"[{self.account.name}] Payment {payment_id} URL: {details.url}")

        logger.info(
            f"[{self.account.name}] Payment details: "
            f"brand={details.brand_name}, amount={details.out_amount} {details.out_asset}"
        )

        if not await self._handler.can_handle(details):
            logger.warning(
                f"[{self.account.name}] Elplat cannot handle payment {payment_id} "
                f"(need qr.nspk.ru URL). brand={details.brand_name}"
            )
            return

        logger.info(f"[{self.account.name}] Using Elplat for payment {payment_id}")
        success = await self._handler.auto_pay(details)

        if success:
            logger.info(f"[{self.account.name}] Auto-pay successful for payment {payment_id}")
            if self.send_bot:
                try:
                    ok, msg = await self.send_bot.complete_qr_payment(payment_id)
                    if ok:
                        logger.info(f"[{self.account.name}] send-bot payment complete acknowledged")
                    else:
                        logger.warning(f"[{self.account.name}] send-bot complete failed: {msg}")
                except Exception as e:
                    logger.exception(f"[{self.account.name}] send-bot complete error: {e}")
        else:
            logger.warning(f"[{self.account.name}] Auto-pay failed for payment {payment_id}")

    def _log_status_change(self, payment_id: int, status: PaymentStatus) -> None:
        """Log payment status changes."""
        status_emoji = {
            PaymentStatus.COMPLETED: "COMPLETED",
            PaymentStatus.CANCELED: "CANCELED",
            PaymentStatus.DISPUTED: "DISPUTED",
            PaymentStatus.REFUNDED: "REFUNDED",
        }
        msg = status_emoji.get(status, status.value.upper())
        logger.info(f"[{self.account.name}] Payment {payment_id} status changed: {msg}")
